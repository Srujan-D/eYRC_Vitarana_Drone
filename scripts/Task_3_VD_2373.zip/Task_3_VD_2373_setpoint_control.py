#!/usr/bin/env python

import rospy
import time,os
from vitarana_drone.msg import *
from std_msgs.msg import *
from sensor_msgs.msg import NavSatFix
from vitarana_drone.srv import Gripper

# Marker Detection
import cv2
import numpy as np
from std_msgs.msg import Float32
from sensor_msgs.msg import Image
from matplotlib import pyplot as plt
from cv_bridge import CvBridge, CvBridgeError

class SetpointControl(object):

    def __init__(self):

        rospy.init_node('setpoint_control')

        self.parcel_setpoint=[19.0007046575, 71.9998955286, 22]

        self.drone_position=[0,0,0]
      
        # start point [18.99924113805385, 71.99981954948407, 16.660023269655206]
        self.setpoint_queue=[[18.9993675932, 72.0000569892, 10.7+17],[18.9990965928,72.0000664814,10.75+10],[18.9990965925, 71.9999050292, 22.2+10]]
            # 18.9991380883
            # 72.0000613935
        self.building_ids=[3,1,2]

        self.marker_setpoints=[[0,0,0]]
        self.setpoint=list(self.setpoint_queue[0])

        self.dest_msg=destination()
        cc_path='/data/cascade.xml'
        abs_cc_path=os.path.dirname(__file__)+cc_path
        self.logo_cascade = cv2.CascadeClassifier(abs_cc_path)
        
        self.img=None
        self.bridge = CvBridge()
        

        self.pub_marker_data=MarkerData()
        self.marker_detected=False
        # QR scanned setpoints
        self.scanned_destination_setpoint=[0,0,0]
        self.destination_set = False
        self.prev_scanner_setpoint=None
        self.go_to_marker=False
        self.marker_point=0

        self.pub_marker_data.marker_id=3

        #  ROS Publishers
        self.setpoint_pub = rospy.Publisher("/edrone/setpoint_control", destination, queue_size=2)
        self.marker_data=rospy.Publisher("/edrone/marker_data", MarkerData, queue_size=1)


        # ROS Subscribers
        rospy.Subscriber("/edrone/gps", NavSatFix, self.gps_callback)
        rospy.Subscriber("/edrone/center_lat_long", center_x_y, self.center_lat_long)

        # rospy.Subscriber("/edrone/camera/image_raw", Image, self.image_callback) #Subscribing to the camera topic

        # rospy.Subscriber("/edrone/qr_scanner",qr_scanner,self.qr_callback)

        # rospy.Subscriber()
        # self.gripper = rospy.ServiceProxy('/edrone/activate_gripper',Gripper())


    def gps_callback(self, msg):
        self.drone_position[0] = msg.latitude
        self.drone_position[1] = msg.longitude
        self.drone_position[2] = msg.altitude


    def qr_callback(self, msg):
        try:
            if msg.alt_z and msg.lat_x and msg.long_y and not self.destination_set:
                
                drop_point=[msg.lat_x,msg.long_y, 25 ]  #msg.alt_z]
                self.add_setpoint_to_queue(drop_point)
                
                self.scanned_destination_setpoint=[msg.lat_x,msg.long_y,msg.alt_z]
                self.add_setpoint_to_queue(self.scanned_destination_setpoint)
                
                self.destination_set=True
        
        except Exception as e:
            print(e)


    def check_range(self,dist,target):
        return (abs(dist - target)>=0.001)

    
    def center_lat_long(self,msg):
        # self.marker_detected=False
        if msg.x and msg.y :
            # self.marker_detected = True
            lat_x = self.x_to_lat(msg.y + self.lat_to_x(self.drone_position[0]))
            long_y = self.y_to_long(msg.x + self.long_to_y(self.drone_position[1]))
            # print(lat_x,long_y)
            marker_setpoint= [lat_x,long_y,self.drone_position[2]]
            print("YAAAAYYYYY")
            print(self.marker_setpoints)
            try:
                if self.check_range(marker_setpoint[0],self.marker_setpoints[self.marker_point][0]) and  self.check_range(marker_setpoint[1],self.marker_setpoints[self.marker_point][1]) :
                    self.marker_setpoints.append(marker_setpoint)
                    print("ADDED")
                    self.marker_point+=1
                    self.go_to_marker=True
            except:
                self.marker_setpoints.append(marker_setpoint)
                print("First ADDED")

            self.pub_marker_data.err_x_m = self.lat_to_x(self.drone_position[0])+msg.x
            self.pub_marker_data.err_y_m = self.long_to_y(self.drone_position[1])+msg.y
            self.pub_marker_data.marker_id=self.building_ids[0]
        else:
            print("no_new_msg",msg)


    def check_proximity(self,target):
        if (
            (
                abs(self.drone_position[0] - target[0])
                <= 0.0000018 #0.000004517
            )
            and (
                abs(self.drone_position[1] - target[1])
                <= 0.0000019 #0.0000047487
            )
            and (
                abs(self.drone_position[2] - target[2])
                <= 0.2
            )
        ):
            return True
        else:
            return False


    def check_setpoint_queue(self):
        
        print(len(self.setpoint_queue))
        if self.go_to_marker and self.check_proximity(self.marker_setpoints[self.marker_point]):
            # self.marker_setpoints.pop(0)
            print("marker popped")
            self.go_to_marker=False
        
        elif self.setpoint_queue and self.check_proximity(self.setpoint_queue[0]):
            try:
                if self.setpoint_queue[1][2] - self.drone_position[2]>=0.1:
                    print("Getting ready")
                    self.setpoint_queue[0]=[self.drone_position[0],self.drone_position[1],self.setpoint_queue[1][2]]
                else:
                    self.setpoint_queue.pop(0)
                    print("POPPED")
                    self.building_ids.pop(0)
                    self.pub_marker_data.marker_id=building_ids[0]
                    self.setpoint=list(self.setpoint_queue[0])
            except Exception as e:
                print("errrrrrrrrr",e)
                self.setpoint=list(self.drone_position)
        
        elif not self.setpoint_queue:
            print("reached")
        
        else:
            print("GOING")


    def add_setpoint_to_queue(self, setpoint):
        print("ADDED", setpoint)
        self.setpoint_queue.append(list(setpoint))
        return
    

    def setpoint_control(self):
        self.check_setpoint_queue()
        print("")
        print(time.strftime("%H:%M:%S"))
        print("")
        pub_msg=destination()
        if self.go_to_marker:
            pub_msg.lat=self.marker_setpoints[self.marker_point][0]
            pub_msg.long=self.marker_setpoints[self.marker_point][1]
            pub_msg.alt=self.marker_setpoints[self.marker_point][2]
            print("Going to marker")
        else:
            pub_msg.lat=self.setpoint[0]
            pub_msg.long=self.setpoint[1]
            pub_msg.alt=self.setpoint[2]


        self.dest_msg=pub_msg
        self.setpoint_pub.publish(pub_msg)


    def x_to_lat(self, input_x):
        return input_x/110692.0702932625 + 19

    def y_to_long(self, input_y):
        return -input_y/(105292.0089353767 )+ 72

    def lat_to_x(self, input_latitude):
        return 110692.0702932625 * (input_latitude - 19)

    def long_to_y(self, input_longitude):
        return -105292.0089353767 * (input_longitude - 72)


    def publish_marker_data(self):
        self.marker_data.publish(self.pub_marker_data)


def main():
    del_control=SetpointControl()
    r = rospy.Rate(50)
    counter = 0
    while not rospy.is_shutdown():
        del_control.setpoint_control()
        # publish marker_data
        if counter==0:
            del_control.publish_marker_data()
            counter+=1
        else:
            counter+=1
            if counter ==50:
                counter=0

        r.sleep()


# Equations of lines

# till parcel
# y= -0.2889644*x + 77.4904233

# till delivery
# y= -0.14825840*x + 74.816909775

if __name__ == "__main__":
    main()